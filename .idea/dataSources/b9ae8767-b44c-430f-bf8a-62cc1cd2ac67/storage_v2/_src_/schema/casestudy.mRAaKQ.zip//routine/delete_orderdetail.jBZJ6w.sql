create
    definer = root@localhost procedure delete_orderdetail(IN id int, IN id2 int)
begin
    delete from orderdetail where orderId = id and productId = id2;
end;

