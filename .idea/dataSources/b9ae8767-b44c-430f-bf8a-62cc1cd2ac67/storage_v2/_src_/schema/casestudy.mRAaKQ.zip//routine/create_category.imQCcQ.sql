create
    definer = root@localhost procedure create_category(IN name varchar(50), IN description varchar(50))
BEGIN

    INSERT INTO category(categoryName, categoryDescription) VALUES(name, description);

END;

