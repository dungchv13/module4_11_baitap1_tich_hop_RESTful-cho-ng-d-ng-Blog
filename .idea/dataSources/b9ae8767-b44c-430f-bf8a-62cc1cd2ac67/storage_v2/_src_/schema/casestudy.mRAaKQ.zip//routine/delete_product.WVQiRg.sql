create
    definer = root@localhost procedure delete_product(IN id int)
begin
    delete from products where productID = id;
end;

