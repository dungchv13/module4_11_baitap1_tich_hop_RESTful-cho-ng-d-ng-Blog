create
    definer = root@localhost procedure create_orderdetail(IN orderId1 int, IN productId1 int, IN quantity1 int, IN amount1 double)
begin
    insert into orderdetail values (orderId1,productId1,quantity1,amount1);
end;

